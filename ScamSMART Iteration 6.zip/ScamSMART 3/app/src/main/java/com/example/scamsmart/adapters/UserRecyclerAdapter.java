package com.example.scamsmart.adapters;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.example.scamsmart.R;
import com.example.scamsmart.models.Post;
import com.example.scamsmart.models.User;
import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import org.jetbrains.annotations.NotNull;

public class UserRecyclerAdapter extends FirestoreRecyclerAdapter<User, UserRecyclerAdapter.UserHolder> {
    /**
     * Create a new RecyclerView adapter that listens to a Firestore Query.  See {@link
     * FirestoreRecyclerOptions} for configuration options.
     *
     * @param options
     */

    Context context;
    public UserRecyclerAdapter(@NonNull FirestoreRecyclerOptions<User> options, Context context) {
        super(options);
        this.context = context;
    }

    @Override
    protected void onBindViewHolder(@NonNull UserRecyclerAdapter.UserHolder holder, int position, @NonNull User model) {
        FirebaseFirestore db = FirebaseFirestore.getInstance();

        holder.tvType.setText(model.getType());
        holder.tvUsername.setText(model.getName());;

        holder.btnGarda.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("CHECKPOSITION",model.getId());
                Toast.makeText(context, "check" + model.getId(), Toast.LENGTH_SHORT).show();
                Dialog Options;
                final String[] fonts = {
                        "Regular", "Admin", "Garda", "Cancel"
                };

                //Launch Dialog Box
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setTitle("What type of user would you like to change " + model.getName() + " to?");
                builder.setItems(fonts, new DialogInterface.OnClickListener() {@
                        Override
                public void onClick(DialogInterface dialog, int which) {
                    if ("Regular".equals(fonts[which])) {
                        //Code for changing
                        Log.d("POSITIONTEST",position + "" + model.getName());

                        DocumentReference userRef = db.collection("Users").document(model.getId());
                        userRef
                                .update("type", "regular")
                                .addOnSuccessListener(new OnSuccessListener<Void>() {
                                    @Override
                                    public void onSuccess(Void aVoid) {
                                        Log.d("TAG", "DocumentSnapshot successfully updated!");
                                    }
                                })
                                .addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        Log.w("TAG", "Error updating document", e);
                                    }
                                });

                    } else if ("Admin".equals(fonts[which])) {
                        //Code for changing
                        Log.d("POSITIONTEST",position + "");

                        DocumentReference washingtonRef = db.collection("Users").document(model.getId());

                        // Set the "isCapital" field of the city 'DC'
                        washingtonRef
                                .update("type", "admin")
                                .addOnSuccessListener(new OnSuccessListener<Void>() {
                                    @Override
                                    public void onSuccess(Void aVoid) {
                                        Log.d("TAG", "DocumentSnapshot successfully updated!");
                                    }
                                })
                                .addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        Log.w("TAG", "Error updating document", e);
                                    }
                                });

                    } else if ("Garda".equals(fonts[which])) {
                        //Code for changing
                        Log.d("POSITIONTEST",position + "");

                        DocumentReference washingtonRef = db.collection("Users").document(model.getId());

                        // Set the "isCapital" field of the city 'DC'
                        washingtonRef
                                .update("type", "garda")
                                .addOnSuccessListener(new OnSuccessListener<Void>() {
                                    @Override
                                    public void onSuccess(Void aVoid) {
                                        Log.d("TAG", "DocumentSnapshot successfully updated!");
                                    }
                                })
                                .addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        Log.w("TAG", "Error updating document", e);
                                    }
                                });

                    } else if ("Cancel".equals(fonts[which])) {

                    }
                    // the user clicked on colors[which]

                }
                });
                builder.show();
            }
        });









    }

    @NonNull
    @Override
    public UserRecyclerAdapter.UserHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.useritem,parent,false);
        return new UserHolder(v);
    }


    class UserHolder extends RecyclerView.ViewHolder  {
        TextView tvUsername;
        TextView tvType;
        Button btnAdmin;
        Button btnRegular;
        Button btnGarda;
        ConstraintLayout parentLayout;

        public UserHolder(@NonNull @NotNull View itemView) {
            super(itemView);
            tvUsername = itemView.findViewById(R.id.tvUsername);
            tvType = itemView.findViewById(R.id.tvType);
            //btnAdmin = itemView.findViewById(R.id.btnAdmin);
            btnGarda = itemView.findViewById(R.id.btnGarda);
            //btnRegular = itemView.findViewById(R.id.btnRegular);
        }
    }



}
