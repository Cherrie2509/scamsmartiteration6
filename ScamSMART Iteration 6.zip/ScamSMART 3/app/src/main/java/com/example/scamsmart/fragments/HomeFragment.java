package com.example.scamsmart.fragments;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.scamsmart.R;
import com.example.scamsmart.ui.MainActivity;
import com.example.scamsmart.ui.nav_activity;
import com.example.scamsmart.ui.recent_firebase_activity;
import com.example.scamsmart.ui.signin_activity;
import com.firebase.ui.auth.AuthUI;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import org.jetbrains.annotations.NotNull;

public class HomeFragment extends Fragment implements View.OnClickListener {


    View view;
    FirebaseAuth auth;
    String name;
    private FirebaseFirestore db = FirebaseFirestore.getInstance();

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {


        getActivity().setTitle("Home");

        auth = FirebaseAuth.getInstance();
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        String email = user.getEmail();
        String userID = auth.getCurrentUser().getUid();
        Log.d("USERIDCHECK",userID);
        view = inflater.inflate(R.layout.fragment_home, container, false);
        Button btnView = view.findViewById(R.id.btnViewRecentPosts);
        Button btnShare = view.findViewById(R.id.btnShareApp);
        Button btnSignOut = view.findViewById(R.id.btnSignOut);
        TextView tv8 = view.findViewById(R.id.textView8);
        TextView tv12 = view.findViewById(R.id.textView12);


        //Retrieving the user from cloud firestore now that we have the ID
        //https://firebase.google.com/docs/firestore/query-data/get-data
        DocumentReference documentReference = db.collection("Users").document(userID);
        documentReference.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        Log.d("TAG", "DocumentSnapshot data: " + document.getData());
                        String temp = String.valueOf(document.getData().get("Name"));
                        setUsername(temp,tv12);

                    } else {
                        Log.d("TAG", "No such document");
                    }
                } else {
                    Log.d("TAG", "get failed with ", task.getException());
                }
            }
        });

        btnView.setOnClickListener(this);
        btnShare.setOnClickListener(this);
        btnSignOut.setOnClickListener(this);
        btnShare.setVisibility(View.INVISIBLE);
        return view;

    }

    private void setUsername(String temp, TextView tv) {
        name = temp;
        tv.setText(name);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnViewRecentPosts:
                Intent intent = new Intent(getActivity(), recent_firebase_activity.class);
                startActivity(intent);
                break;
            case R.id.btnShareApp:
                Intent sendIntent = new Intent(Intent.ACTION_VIEW);
                sendIntent.setData(Uri.parse("sms:"));
                sendIntent.putExtra("sms_body", "Check out this new app called ScamSMART! It helps us to stay informed of new scams. *Google Play Link*");
                startActivity(sendIntent);
                break;
            case R.id.btnSignOut:
                AuthUI.getInstance()
                        .signOut(getActivity())
                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull @NotNull Task<Void> task) {
                                Intent intent = new Intent(getActivity(), signin_activity.class);
                                startActivity(intent);
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull @NotNull Exception e) {
                        Toast.makeText(getActivity(), "Sign Out Failed", Toast.LENGTH_SHORT).show();
                    }
                });
        }
    }
}
