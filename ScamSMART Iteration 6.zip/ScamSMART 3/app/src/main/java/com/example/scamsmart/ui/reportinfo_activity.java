package com.example.scamsmart.ui;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.Gravity;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.scamsmart.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import org.jetbrains.annotations.NotNull;

public class reportinfo_activity extends AppCompatActivity {



    FirebaseFirestore fStore;
    String article;
    TextView tvContent;
    String formattedarticle;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reportinfo_activity);

        fStore = FirebaseFirestore.getInstance();
        tvContent = findViewById(R.id.tvPhoneinfoContent);

        setTitle("How to Report");
        ActionBar actionBar;
        actionBar = getSupportActionBar();
        ColorDrawable colorDrawable
                = new ColorDrawable(Color.parseColor("#f64c73"));
        // Set BackgroundDrawable
        actionBar.setBackgroundDrawable(colorDrawable);
        actionBar.setDisplayOptions(actionBar.getDisplayOptions()
                | ActionBar.DISPLAY_SHOW_CUSTOM);
        ImageView imageView = new ImageView(actionBar.getThemedContext());
        imageView.setScaleType(ImageView.ScaleType.CENTER);
        imageView.setImageResource(R.drawable.scamsmartactiontiny);
        ActionBar.LayoutParams layoutParams = new ActionBar.LayoutParams(
                ActionBar.LayoutParams.WRAP_CONTENT,
                ActionBar.LayoutParams.WRAP_CONTENT, Gravity.RIGHT
                | Gravity.CENTER_VERTICAL);
        //layoutParams.leftMargin = 40;
        imageView.setLayoutParams(layoutParams);
        actionBar.setCustomView(imageView);


        //Retrieving the document which contains the content for this activity
        DocumentReference documentReference = fStore.collection("InfoContent").document("ReportInfo");
        documentReference.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull @NotNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    Log.d("DB*****",document.getData().get("Article") + "");
                    article = String.valueOf(document.getData().get("Article"));
                    if(article.contains("_n")) {
                        formattedarticle = article.replace("_n","\n");
                    }
                    Log.d("CHECKARRAY",article);
                    addtoArticle(formattedarticle);
                }
                else {
                    Toast.makeText(reportinfo_activity.this, "Nothing retrieved" + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                }

            }
        });

        //Make content scrollable, adapted from https://stackoverflow.com/questions/1748977/making-textview-scrollable-on-android
        tvContent.setMovementMethod(new ScrollingMovementMethod());

    }
    private void addtoArticle(String article) {
        tvContent.setText(article);
    }
}