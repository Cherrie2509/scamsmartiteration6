package com.example.scamsmart.ui;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.ImageView;

import com.example.scamsmart.R;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.BarLineChartBase;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.formatter.PercentFormatter;
import com.github.mikephil.charting.formatter.ValueFormatter;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.github.mikephil.charting.utils.ViewPortHandler;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class stats_activity extends AppCompatActivity {


    FirebaseFirestore fStore;
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private CollectionReference postRef = db.collection("Posts");
    Integer intJanCount;
    Integer intFebCount;
    Integer intMarCount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stats_activity);
        intJanCount = 0;
        intFebCount = 0;
        intMarCount = 0;
        BarChart barChart = findViewById(R.id.bcScams);

        setTitle("Scams by Month");
        ActionBar actionBar;
        actionBar = getSupportActionBar();
        ColorDrawable colorDrawable
                = new ColorDrawable(Color.parseColor("#f64c73"));
        // Set BackgroundDrawable
        actionBar.setBackgroundDrawable(colorDrawable);
        actionBar.setDisplayOptions(actionBar.getDisplayOptions()
                | ActionBar.DISPLAY_SHOW_CUSTOM);
        ImageView imageView = new ImageView(actionBar.getThemedContext());
        imageView.setScaleType(ImageView.ScaleType.CENTER);
        imageView.setImageResource(R.drawable.scamsmartactiontiny);
        ActionBar.LayoutParams layoutParams = new ActionBar.LayoutParams(
                ActionBar.LayoutParams.WRAP_CONTENT,
                ActionBar.LayoutParams.WRAP_CONTENT, Gravity.RIGHT
                | Gravity.CENTER_VERTICAL);
        //layoutParams.leftMargin = 40;
        imageView.setLayoutParams(layoutParams);
        actionBar.setCustomView(imageView);

        fStore = FirebaseFirestore.getInstance();

        CollectionReference citiesRef = db.collection("Posts");

        citiesRef.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if(task.isSuccessful()) {
                    for(DocumentSnapshot documentSnapshot : task.getResult()) {
                        String timestamp;

                        //Adapted from https://stackoverflow.com/a/54838761
                        timestamp = (String) documentSnapshot.getTimestamp("timestamp").toDate().toString();

                        if(timestamp.contains("Jan")) {
                            intJanCount++;
                        }
                        else if(timestamp.contains("Feb")) {
                            intFebCount++;
                        }
                        else if(timestamp.contains("Mar")) {
                            intMarCount++;
                        }

                    }
                    setupBarChart(barChart,intJanCount,intFebCount, intMarCount);

                }
            }
        });

    }

    private void setupBarChart(BarChart barChart, Integer janCount, Integer FebCount, Integer MarCount) {
        //https://stackoverflow.com/a/56945823
        //https://github.com/PhilJay/MPAndroidChart/issues/978
        //https://stackoverflow.com/questions/57748668/center-x-axis-labels-in-center-of-points-in-android-mpandroidchart-barchart
        ArrayList<BarEntry> scams = new ArrayList<>();
        scams.add(new BarEntry(1,janCount));
        scams.add(new BarEntry(2,FebCount));
        scams.add(new BarEntry(3,MarCount));
        List<String> xAxisValues = new ArrayList<>(Arrays.asList("J", "Jan", "Feb", "Mar"));
        BarDataSet barDataSet = new BarDataSet(scams,"Number of Scams");
        barDataSet.setColors(ColorTemplate.MATERIAL_COLORS);
        barDataSet.setValueTextColor(Color.BLACK);
        barDataSet.setValueTextSize(18f);
        barChart.getDescription().setText("");
        BarData barData = new BarData(barDataSet);
        barChart.setFitBars(true);
        barChart.setData(barData);
        barData.setValueFormatter(new MyValueFormatter());
        calculateMinMax(barChart,4);
        barChart.animateY(2000);
        barChart.getXAxis().setValueFormatter(new com.github.mikephil.charting.formatter.IndexAxisValueFormatter(xAxisValues));
        barChart.getXAxis().setPosition(XAxis.XAxisPosition.BOTTOM);
        YAxis rightYAxis = barChart.getAxisRight();
        rightYAxis.setEnabled(false);
        YAxis leftYAxis = barChart.getAxisLeft();
        leftYAxis.setValueFormatter(new MyValueFormatter());
        leftYAxis.setGranularity(1.0f);
        leftYAxis.setGranularityEnabled(true);
        XAxis xAxis = barChart.getXAxis();
        xAxis.setCenterAxisLabels(false);
        xAxis.setLabelCount(4);
    }

    //https://stackoverflow.com/a/44800697
    public class MyValueFormatter extends ValueFormatter {

        private DecimalFormat mFormat;

        public MyValueFormatter() {
            mFormat = new DecimalFormat("#");
        }

        @Override
        public String getFormattedValue(float value) {
            return mFormat.format(value);
        }
    }
    //https://stackoverflow.com/a/41788628
    private void calculateMinMax(BarLineChartBase chart, int labelCount) {
        float maxValue = chart.getData().getYMax();
        float minValue = chart.getData().getYMin();

        if ((maxValue - minValue) < labelCount) {
            float diff = labelCount - (maxValue - minValue);
            maxValue = maxValue + diff;
            chart.getAxisLeft().setAxisMaximum(maxValue);
            chart.getAxisLeft().setAxisMinimum(minValue);
        }
    }

}