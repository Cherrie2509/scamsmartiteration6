package com.example.scamsmart.models;

public class User {


     private String id;
     private String Name;
     private String type;

    public User() {
    }

    public User(String id, String name, String type) {
        this.id = id;
        Name = name;
        this.type = type;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        this.Name = name;
    }
}
