package com.example.scamsmart.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.scamsmart.R;
import com.example.scamsmart.ui.block_activity;
import com.example.scamsmart.ui.quiz_activity;
import com.example.scamsmart.ui.report_activity;

public class ReportFragment extends Fragment implements View.OnClickListener {


    View view;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view =  inflater.inflate(R.layout.fragment_report, container, false);
        Button btnReport = view.findViewById(R.id.btnReportScam);
        Button btnBlock = view.findViewById(R.id.btnBlockNumber);
        getActivity().setTitle("Report & Block");
        btnReport.setOnClickListener(this);
        btnBlock.setOnClickListener(this);
        return view;
    }

    @Override
    public void onClick(View v) {
        switch(v.getId()) {
            case R.id.btnReportScam:
                Intent intent = new Intent(getActivity(), report_activity.class);
                startActivity(intent);
                break;
            case R.id.btnBlockNumber:
                Intent intent2 = new Intent(getActivity(), block_activity.class);
                startActivity(intent2);
                break;
        }
    }
}
