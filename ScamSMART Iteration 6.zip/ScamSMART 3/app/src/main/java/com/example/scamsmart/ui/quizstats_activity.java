package com.example.scamsmart.ui;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.ImageView;

import com.example.scamsmart.R;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.BarLineChartBase;
import com.github.mikephil.charting.components.Description;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.formatter.ValueFormatter;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class quizstats_activity extends AppCompatActivity {



    FirebaseFirestore fStore;
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    Double totalResult;
    Double JanCounter;
    Double FebCounter;
    Double MarCounter;
    Double JanResult;
    Double FebResult;
    Double MarResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quizstats_activity);

        setTitle("Average % Results");
        ActionBar actionBar;
        actionBar = getSupportActionBar();
        ColorDrawable colorDrawable
                = new ColorDrawable(Color.parseColor("#f64c73"));
        // Set BackgroundDrawable
        actionBar.setBackgroundDrawable(colorDrawable);
        actionBar.setDisplayOptions(actionBar.getDisplayOptions()
                | ActionBar.DISPLAY_SHOW_CUSTOM);
        ImageView imageView = new ImageView(actionBar.getThemedContext());
        imageView.setScaleType(ImageView.ScaleType.CENTER);
        imageView.setImageResource(R.drawable.scamsmartactiontiny);
        ActionBar.LayoutParams layoutParams = new ActionBar.LayoutParams(
                ActionBar.LayoutParams.WRAP_CONTENT,
                ActionBar.LayoutParams.WRAP_CONTENT, Gravity.RIGHT
                | Gravity.CENTER_VERTICAL);
        //layoutParams.leftMargin = 40;
        imageView.setLayoutParams(layoutParams);
        actionBar.setCustomView(imageView);


        totalResult = 0.0;
        JanCounter = 0.0;
        FebCounter = 0.0;
        MarCounter = 0.0;
        JanResult = 0.0;
        FebResult = 0.0;
        MarResult = 0.0;

        BarChart barChart = findViewById(R.id.bcQuiz);

        fStore = FirebaseFirestore.getInstance();

        CollectionReference citiesRef = db.collection("QuizResults");

        citiesRef.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if(task.isSuccessful()) {

                    for(DocumentSnapshot documentSnapshot : task.getResult()) {

                        String timestamp;
                        //Adapted from https://stackoverflow.com/a/54838761
                        timestamp = (String) documentSnapshot.getTimestamp("Timestamp").toDate().toString();

                        if(timestamp.contains("Jan")) {
                            JanResult += documentSnapshot.getDouble("Result");
                            JanCounter += 1.0;
                        }

                        if(timestamp.contains("Feb")) {
                            FebResult += documentSnapshot.getDouble("Result");
                            FebCounter += 1.0;
                        }

                        if(timestamp.contains("Mar")) {
                            MarResult += documentSnapshot.getDouble("Result");
                            MarCounter += 1.0;
                        }



                    }

                    setupBarChart(barChart,JanResult/JanCounter, FebResult/FebCounter, MarResult/MarCounter);

                }
            }
        });

    }

    private void setupBarChart(BarChart barChart, Double JanResult, Double FebResult, Double MarResult) {
        //https://stackoverflow.com/a/56945823
        //https://github.com/PhilJay/MPAndroidChart/issues/978
        //https://stackoverflow.com/questions/57748668/center-x-axis-labels-in-center-of-points-in-android-mpandroidchart-barchart

        ArrayList<BarEntry> scams = new ArrayList<>();
        int convertedresultJan = (int) Math.round(JanResult);
        int convertedresultFeb = (int) Math.round(FebResult);
        int convertedresultMar = (int) Math.round(MarResult);
        scams.add(new BarEntry(1,convertedresultJan));
        scams.add(new BarEntry(2,convertedresultFeb));
        scams.add(new BarEntry(3,convertedresultMar));
        List<String> xAxisValues = new ArrayList<>(Arrays.asList("J", "Jan", "Feb", "Mar"));
        BarDataSet barDataSet = new BarDataSet(scams,"Quiz Results %");
        //Changing the color of the bar
        barDataSet.setColor(Color.parseColor("#304567"));    //Setting the size of the form in the legend
        barDataSet.setFormSize(15f);    //showing the value of the bar, default true if not set
        barDataSet.setDrawValues(false);    //setting the text size of the value of the bar
        barDataSet.setValueTextSize(12f);
        BarData data = new BarData(barDataSet);
        //hiding the grey background of the chart, default false if not set
        barChart.setDrawGridBackground(false);
        //remove the bar shadow, default false if not set
        barChart.setDrawBarShadow(false);
        //remove border of the chart, default false if not set
        barChart.setDrawBorders(false);

        //remove the description label text located at the lower right corner
        Description description = new Description();
        description.setEnabled(false);
        barChart.setDescription(description);

        //setting animation for y-axis, the bar will pop up from 0 to its value within the time we set
        barChart.animateY(1000);
        //setting animation for x-axis, the bar will pop up separately within the time we set
        barChart.animateX(1000);

        XAxis xAxis = barChart.getXAxis();
        //change the position of x-axis to the bottom
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        //set the horizontal distance of the grid line
        xAxis.setGranularity(1f);
        //hiding the x-axis line, default true if not set
        xAxis.setDrawAxisLine(false);
        //hiding the vertical grid lines, default true if not set
        xAxis.setDrawGridLines(false);
        barChart.getXAxis().setValueFormatter(new com.github.mikephil.charting.formatter.IndexAxisValueFormatter(xAxisValues));

        YAxis leftAxis = barChart.getAxisLeft();
        //hiding the left y-axis line, default true if not set
        leftAxis.setDrawAxisLine(false);

        YAxis rightAxis = barChart.getAxisRight();
        //hiding the right y-axis line, default true if not set
        rightAxis.setDrawAxisLine(false);

        Legend legend = barChart.getLegend();
        //setting the shape of the legend form to line, default square shape
        legend.setForm(Legend.LegendForm.LINE);
        //setting the text size of the legend
        legend.setTextSize(11f);
        //setting the alignment of legend toward the chart
        legend.setVerticalAlignment(Legend.LegendVerticalAlignment.BOTTOM);
        legend.setHorizontalAlignment(Legend.LegendHorizontalAlignment.LEFT);
        //setting the stacking direction of legend
        legend.setOrientation(Legend.LegendOrientation.HORIZONTAL);
        //setting the location of legend outside the chart, default false if not set
        legend.setDrawInside(false);
        barChart.setData(data);
        barChart.invalidate();
//        barDataSet.setColors(ColorTemplate.MATERIAL_COLORS);
//        barDataSet.setValueTextColor(Color.BLACK);
//        barDataSet.setValueTextSize(18f);
//        barChart.getDescription().setText("");
//        BarData barData = new BarData(barDataSet);
//        barChart.setFitBars(true);
//        barChart.setData(barData);
//        barData.setValueFormatter(new quizstats_activity.MyValueFormatter());
//        calculateMinMax(barChart,2);
//        barChart.animateY(2000);
//        barChart.getXAxis().setValueFormatter(new com.github.mikephil.charting.formatter.IndexAxisValueFormatter(xAxisValues));
//        barChart.getXAxis().setPosition(XAxis.XAxisPosition.BOTTOM);
//        YAxis rightYAxis = barChart.getAxisRight();
//        rightYAxis.setEnabled(false);
//        YAxis leftYAxis = barChart.getAxisLeft();
//        leftYAxis.setValueFormatter(new quizstats_activity.MyValueFormatter());
//        leftYAxis.setGranularity(1.0f);
//        leftYAxis.setGranularityEnabled(true);
//        XAxis xAxis = barChart.getXAxis();
//        xAxis.setCenterAxisLabels(false);
//        xAxis.setLabelCount(1);
    }

//    //https://stackoverflow.com/a/44800697
//    public class MyValueFormatter extends ValueFormatter {
//
//        private DecimalFormat mFormat;
//
//        public MyValueFormatter() {
//            mFormat = new DecimalFormat("#");
//        }
//
//        @Override
//        public String getFormattedValue(float value) {
//            return mFormat.format(value);
//        }
//    }
//    //https://stackoverflow.com/a/41788628
//    private void calculateMinMax(BarLineChartBase chart, int labelCount) {
//        float maxValue = chart.getData().getYMax();
//        float minValue = chart.getData().getYMin();
//
//        if ((maxValue - minValue) < labelCount) {
//            float diff = labelCount - (maxValue - minValue);
//            maxValue = maxValue + diff;
//            chart.getAxisLeft().setAxisMaximum(maxValue);
//            chart.getAxisLeft().setAxisMinimum(minValue);
//        }
//    }









}