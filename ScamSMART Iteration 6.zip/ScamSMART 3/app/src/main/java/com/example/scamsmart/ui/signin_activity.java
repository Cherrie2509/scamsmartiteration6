package com.example.scamsmart.ui;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.text.Html;
import android.text.TextUtils;
import android.util.Log;
import android.util.Patterns;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.scamsmart.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import org.jetbrains.annotations.NotNull;

public class signin_activity extends AppCompatActivity {



    //Allows the user to sign in
    //Adapted from https://github.com/bikashthapa01/firebase-authentication-android/blob/master/app/src/main/java/net/smallacademy/authenticatorapp/Login.java


    Button btnSignin, btnRegister, btnViewIntro;
    EditText etEmail, etPassword;
    FirebaseAuth auth;
    FirebaseFirestore fStore;
    String userID, isAdmin;
    TextView tvForgotPassword;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signin);


        tvForgotPassword = findViewById(R.id.tvforgotPW);



        auth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();

        setTitle("Sign In");
        ActionBar actionBar;
        actionBar = getSupportActionBar();
        ColorDrawable colorDrawable
                = new ColorDrawable(Color.parseColor("#f64c73"));
        // Set BackgroundDrawable
        actionBar.setBackgroundDrawable(colorDrawable);
        actionBar.setDisplayOptions(actionBar.getDisplayOptions()
                | ActionBar.DISPLAY_SHOW_CUSTOM);
        ImageView imageView = new ImageView(actionBar.getThemedContext());
        imageView.setScaleType(ImageView.ScaleType.CENTER);
        imageView.setImageResource(R.drawable.scamsmartactiontiny);
        ActionBar.LayoutParams layoutParams = new ActionBar.LayoutParams(
                ActionBar.LayoutParams.WRAP_CONTENT,
                ActionBar.LayoutParams.WRAP_CONTENT, Gravity.RIGHT
                | Gravity.CENTER_VERTICAL);
        //layoutParams.leftMargin = 40;
        imageView.setLayoutParams(layoutParams);
        actionBar.setCustomView(imageView);

        //If the user is already signed in, send them to the main activity
        if(auth.getCurrentUser() != null) {

            userID = auth.getCurrentUser().getUid();

            Log.d("UID******",userID);
            DocumentReference documentReference = fStore.collection("Users").document(userID);
            documentReference.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                @Override
                public void onComplete(@NonNull @NotNull Task<DocumentSnapshot> task) {
                    if (task.isSuccessful()) {
                        DocumentSnapshot document = task.getResult();

                        isAdmin = String.valueOf(document.getData().get("type"));
                        Log.d("CHECKARRAY",isAdmin);
                        //This determines whether the user is sent to the regular section or the admin section
                        checkifAdmin(isAdmin);
                    }
                    else {
                        Toast.makeText(signin_activity.this, "Nothing retrieved" + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                    }

                }
            });
        }

        btnSignin = findViewById(R.id.btnSignin);
        btnRegister = findViewById(R.id.btngotoRegister);
        etEmail = findViewById(R.id.etsigninemail);
        etPassword = findViewById(R.id.etsigninpassword);

        btnViewIntro = findViewById(R.id.btnVIewIntro);

        btnViewIntro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Code based on: IS4407 Lecture Material, Gleeson Michael
                //Code from: Microsoft Team -> Teams -> IS4447 Tutorial Series -> File -> Bonus - Happy Christmas
                PrefManager PrefManagerActivity = new PrefManager(getApplicationContext());
                // make first time launch TRUE
                PrefManagerActivity.setFirstTimeLaunch(true);
                startActivity(new Intent(signin_activity.this, WelcomeActivity.class));
                finish();
                //End Code
            }
        });

        tvForgotPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog.Builder alertName = new AlertDialog.Builder(signin_activity.this,R.style.AlertDialogTheme);
                final EditText editTextName1 = new EditText(signin_activity.this);
                // add line after initializing editTextName1
                editTextName1.setHint("Please Enter your email");
//                editTextName1.setTextColor(Color.GRAY);

                alertName.setTitle( Html.fromHtml("Reset Password"));
                // titles can be used regardless of a custom layout or not
                alertName.setView(editTextName1);
                LinearLayout layoutName = new LinearLayout(signin_activity.this);
                layoutName.setOrientation(LinearLayout.VERTICAL);
                layoutName.addView(editTextName1); // displays the user input bar
                alertName.setView(layoutName);



                alertName.setPositiveButton(Html.fromHtml("<font color='#00000'>Reset Password</font>"), new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {

                        if (!(Patterns.EMAIL_ADDRESS.matcher(editTextName1.getText().toString()).matches())) {
                            editTextName1.setError("Please enter a valid email");
                            editTextName1.requestFocus();

                        }
                        else {
                            FirebaseAuth auth = FirebaseAuth.getInstance();

                            auth.sendPasswordResetEmail(editTextName1.getText().toString())
                                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            if (task.isSuccessful()) {
                                                Toast.makeText(signin_activity.this, "Email Sent", Toast.LENGTH_SHORT).show();
                                            }
                                            else {
                                                Toast.makeText(signin_activity.this, "Please ensure you entered a valid email", Toast.LENGTH_SHORT).show();
                                            }
                                        }
                                    });
                        }

                    }
                });

                alertName.setNegativeButton(Html.fromHtml("<font color='#00000'>Cancel</font>"), new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {
                        dialog.cancel(); // closes dialog alertName.show() // display the dialog

                    }
                });


                alertName.show();



            }
        });

        //Passes the email and password to firebase auth, which then determines if the details are correct
        btnSignin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String email = etEmail.getText().toString().trim();
                String password = etPassword.getText().toString().trim();

                //Validation
                if(TextUtils.isEmpty(email)){
                    etEmail.setError("Email is Required.");
                    return;
                }

                if(TextUtils.isEmpty(password)){
                    etPassword.setError("Password is Required.");
                    return;
                }

                if(password.length() < 6){
                    etPassword.setError("Password Must be >= 6 Characters");
                    return;
                }

                auth.signInWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull @NotNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {

                            userID = auth.getCurrentUser().getUid();

                            Log.d("UID******",userID);
                            DocumentReference documentReference = fStore.collection("Users").document(userID);
                            documentReference.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                                @Override
                                public void onComplete(@NonNull @NotNull Task<DocumentSnapshot> task) {
                                    if (task.isSuccessful()) {
                                        DocumentSnapshot document = task.getResult();

                                        isAdmin = String.valueOf(document.getData().get("type"));
                                        Log.d("CHECKARRAY",isAdmin);
                                        //This determines whether the user is sent to the regular section or the admin section
                                        checkifAdmin(isAdmin);
                                    }
                                    else {
                                        Toast.makeText(signin_activity.this, "Nothing retrieved" + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                                    }

                                }
                            });
                        }
                        else {
                            Toast.makeText(signin_activity.this, task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        });

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(signin_activity.this,register_activity.class);
                startActivity(intent);
            }
        });


    }
    
    public void checkifAdmin(String admin) {

        if(admin.equals("regular")) {
            Toast.makeText(signin_activity.this, "Signed In - Not Admin", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(signin_activity.this,nav_activity.class);
            startActivity(intent);
        }
        else if(admin.equals("admin")) {
            Toast.makeText(signin_activity.this, "Signed In - Admin", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(signin_activity.this,adminmenu_activity.class);
            startActivity(intent);
        }
        else {
            Toast.makeText(signin_activity.this, "Signed In - Garda", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(signin_activity.this,gardamenu_activity.class);
            startActivity(intent);
        }
    }
}
