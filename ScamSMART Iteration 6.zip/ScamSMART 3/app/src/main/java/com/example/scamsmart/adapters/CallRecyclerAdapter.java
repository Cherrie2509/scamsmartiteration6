package com.example.scamsmart.adapters;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.example.scamsmart.R;
import com.example.scamsmart.models.Call;
import com.example.scamsmart.ui.block_activity;
import com.example.scamsmart.ui.report_activity;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

public class CallRecyclerAdapter  extends RecyclerView.Adapter<CallRecyclerAdapter.MyViewHolder> {

    //Adapted From this video https://www.youtube.com/watch?v=FFCpjZkqfb0
    //Adapter to display the call log

    List<Call> callList;
    List<String> reportedNumbers = new ArrayList<>();
    Context context;
    FirebaseFirestore fStore;

    public CallRecyclerAdapter(List<Call> callList, Context context) {
        this.callList = callList;
        this.context = context;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView tvDate;
        TextView tvNumber;

        TextView tvDuration;
        TextView tvType;
        Button btnBlock;
        Button btnReport;


        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            tvDate = itemView.findViewById(R.id.tvDate);
            //tvDuration = itemView.findViewById(R.id.tvDuration);
            tvNumber = itemView.findViewById(R.id.tvNumber);
           // tvType = itemView.findViewById(R.id.tvType);
            btnBlock = itemView.findViewById(R.id.btnBlockLog);
            btnReport = itemView.findViewById(R.id.btnReportLog);


        }
    }



    @NonNull
    @Override
    public CallRecyclerAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.onecall,parent,false);
        CallRecyclerAdapter.MyViewHolder holder = new CallRecyclerAdapter.MyViewHolder(view);

        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull CallRecyclerAdapter.MyViewHolder holder, int position) {



        fStore = FirebaseFirestore.getInstance();
        CollectionReference collectionReference = fStore.collection("Posts");
        collectionReference.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if(task.isSuccessful()) {
                    for(DocumentSnapshot documentSnapshot : task.getResult()) {

                        //Adapted from https://stackoverflow.com/a/54838761
                        Log.d("TESTPRINT",documentSnapshot.getString("number"));
                        //reportedNumbers.add("String");
                        reportedNumbers.add(documentSnapshot.getString("number"));



                    }
                    for(String number : reportedNumbers) {
                            if(callList.get(position).getPhNumber().equals(number)) {
                                holder.btnReport.setText("Already Reported");
                                holder.btnReport.setEnabled(false);
                            }
                    }
                }
            }
        });


       // holder.tvDuration.setText(callList.get(position).getCallDuration());
        holder.tvNumber.setText(callList.get(position).getPhNumber());
        holder.tvDate.setText(callList.get(position).getDateString());
        holder.btnBlock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, block_activity.class);
                intent.putExtra("Number", callList.get(position).getPhNumber());
                context.startActivity(intent);
            }
        });

        holder.btnReport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, report_activity.class);
                intent.putExtra("Number", callList.get(position).getPhNumber());
                context.startActivity(intent);
            }
        });




        //holder.tvType.setText(callList.get(position).getCallType());



    }


    @Override
    public int getItemCount() {
        return callList.size();

    }








}
