package com.example.scamsmart.ui;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.ImageView;

import com.anychart.AnyChart;
import com.anychart.AnyChartView;
import com.anychart.chart.common.dataentry.DataEntry;
import com.anychart.charts.Map;
import com.anychart.core.map.series.Choropleth;
import com.anychart.core.ui.ColorRange;
import com.anychart.enums.HAlign;
import com.anychart.enums.SelectionMode;
import com.anychart.enums.SidePosition;
import com.anychart.scales.LinearColor;
import com.example.scamsmart.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

public class mapstats_activity extends AppCompatActivity {

    FirebaseFirestore fStore;
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private CollectionReference postRef = db.collection("Posts");

    private int CarlowCounter;
    private int CavanCounter;
    private int ClareCounter;
    private int CorkCounter;
    private int DonegalCounter;
    private int DublinCounter;
    private int GalwayCounter;
    private int KerryCounter;
    private int KildareCounter;
    private int KilkennyCounter;
    private int LaoisCounter;
    private int LeitrimCounter;
    private int LimerickCounter;
    private int LongfordCounter;
    private int LouthCounter;
    private int MayoCounter;
    private int MeathCounter;
    private int MonaghanCounter;
    private int OffalyCounter;
    private int RoscommonCounter;
    private int SligoCounter;
    private int TipperaryCounter;
    private int WaterfordCounter;
    private int WestMeathCounter;
    private int WexfordCounter;
    private int WicklowCounter;




    //This activity was adapted from the sample app provided by AnyChart
    //https://github.com/AnyChart/AnyChart-Android

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mapstats_activity);
        CarlowCounter = 0;
        CavanCounter = 0;
        ClareCounter = 0;
        CorkCounter = 0;
        DonegalCounter = 0;
        DublinCounter = 0;
        GalwayCounter = 0;
        KerryCounter = 0;
        KildareCounter = 0;
        KilkennyCounter = 0;
        LaoisCounter = 0;
        LeitrimCounter = 0;
        LimerickCounter = 0;
        LongfordCounter = 0;
        LouthCounter = 0;
        MayoCounter = 0;
        MeathCounter = 0;
        MonaghanCounter = 0;
        OffalyCounter = 0;
        RoscommonCounter = 0;
        SligoCounter = 0;
        TipperaryCounter = 0;
        WaterfordCounter = 0;
        WestMeathCounter = 0;
        WexfordCounter = 0;
        WicklowCounter = 0;


        AnyChartView anyChartView = findViewById(R.id.any_chart_view);
        anyChartView.setProgressBar(findViewById(R.id.progress_bar));

        fStore = FirebaseFirestore.getInstance();

        setTitle("County Stats");
        ActionBar actionBar;
        actionBar = getSupportActionBar();
        ColorDrawable colorDrawable
                = new ColorDrawable(Color.parseColor("#f64c73"));
        // Set BackgroundDrawable
        actionBar.setBackgroundDrawable(colorDrawable);
        actionBar.setDisplayOptions(actionBar.getDisplayOptions()
                | ActionBar.DISPLAY_SHOW_CUSTOM);
        ImageView imageView = new ImageView(actionBar.getThemedContext());
        imageView.setScaleType(ImageView.ScaleType.CENTER);
        imageView.setImageResource(R.drawable.scamsmartactiontiny);
        ActionBar.LayoutParams layoutParams = new ActionBar.LayoutParams(
                ActionBar.LayoutParams.WRAP_CONTENT,
                ActionBar.LayoutParams.WRAP_CONTENT, Gravity.RIGHT
                | Gravity.CENTER_VERTICAL);
        //layoutParams.leftMargin = 40;
        imageView.setLayoutParams(layoutParams);
        actionBar.setCustomView(imageView);

        CollectionReference provincesRef = db.collection("Posts");

        provincesRef.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if(task.isSuccessful()) {
                    for(DocumentSnapshot documentSnapshot : task.getResult()) {
                        String county;

                        //Adapted from https://stackoverflow.com/a/54838761
                        county = (String) documentSnapshot.get("County").toString();

                        if(county.contains("Carlow")) {
                           CarlowCounter++;
                        }
                        else if(county.contains("Cavan")) {
                            CavanCounter++;
                        }
                        else if(county.contains("Clare")) {
                           ClareCounter++;
                        }
                        else if(county.contains("Cork")) {
                            CorkCounter++;
                        }
                        else if(county.contains("Donegal")) {
                            DonegalCounter++;
                        }
                        else if(county.contains("Dublin")) {
                            DublinCounter++;
                        }
                        else if(county.contains("Galway")) {
                            GalwayCounter++;
                        }
                        else if(county.contains("Kerry")) {
                            KerryCounter++;
                        }
                        else if(county.contains("Kildare")) {
                            KildareCounter++;
                        }
                        else if(county.contains("Kilkenny")) {
                            KilkennyCounter++;
                        }
                        else if(county.contains("Laois")) {
                            LaoisCounter++;
                        }
                        else if(county.contains("Leitrim")) {
                            LeitrimCounter++;
                        }
                        else if(county.contains("Limerick")) {
                            LimerickCounter++;
                        }
                        else if(county.contains("Longford")) {
                            LongfordCounter++;
                        }
                        else if(county.contains("Louth")) {
                            LouthCounter++;
                        }
                        else if(county.contains("Mayo")) {
                            MayoCounter++;
                        }
                        else if(county.contains("Meath")) {
                            MeathCounter++;
                        }
                        else if(county.contains("Monaghan")) {
                           MonaghanCounter++;
                        }
                        else if(county.contains("Offaly")) {
                            OffalyCounter++;
                        }
                        else if(county.contains("Roscommon")) {
                            RoscommonCounter++;
                        }
                        else if(county.contains("Sligo")) {
                            SligoCounter++;
                        }
                        else if(county.contains("Tipperary")) {
                            TipperaryCounter++;
                        }
                        else if(county.contains("Waterford")) {
                            WaterfordCounter++;
                        }
                        else if(county.contains("Westmeath")) {
                            WestMeathCounter++;
                        }
                        else if(county.contains("Wexford")) {
                            WexfordCounter++;
                        }
                        else if(county.contains("Wicklow")) {
                            WicklowCounter++;
                        }

                    }

                    Map map = AnyChart.map();

                    map.title()
                            .enabled(true)
                            .useHtml(true)
                            .hAlign(String.valueOf(HAlign.CENTER))
                            .fontFamily("Verdana, Helvetica, Arial, sans-serif")
                            .padding(10, 0, 10, 0)
                            .text("<span style=\"color:#7c868e; font-size: 18px\"> Scams Reported By County.</span> <br>" +
                                    "<span style=\"color:#545f69; font-size: 14px\">Amount of scams " +
                                    "reported by county since ScamSMART launch.</span>");

                    map.credits()
                            .enabled(false)
                            .url("https://en.wikipedia.org/wiki/List_of_sovereign_states_and_dependent_territories_by_population_density")
                            .text("Data source: https://en.wikipedia.org/wiki/List_of_sovereign_states_and_dependent_territories_by_population_density")
                            .logoSrc("https://static.anychart.com/images/maps_samples/USA_Map_with_Linear_Scale/favicon.ico");

                    map.geoData("anychart.maps.ireland");

                    ColorRange colorRange = map.colorRange();
                    colorRange.enabled(true)
                            .colorLineSize(10)
                            .stroke("#B9B9B9")
                            .labels("{ 'padding': 3 }")
                            .labels("{ 'size': 7 }");
                    colorRange.ticks()
                            .enabled(true)
                            .stroke("#B9B9B9")
                            .position(SidePosition.OUTSIDE)
                            .length(10);
                    colorRange.minorTicks()
                            .enabled(true)
                            .stroke("#B9B9B9")
                            .position("outside")
                            .length(5);

                    map.interactivity().selectionMode(SelectionMode.NONE);
                    map.padding(0, 0, 0, 0);

                    Choropleth series = map.choropleth(getData());
                    LinearColor linearColor = LinearColor.instantiate();
                    linearColor.colors(new String[]{ "#c2e9fb", "#81d4fa", "#01579b", "#002746"});
                    series.colorScale(linearColor);
                    series.hovered()
                            .fill("#f48fb1")
                            .stroke("#f99fb9");
                    series.selected()
                            .fill("#c2185b")
                            .stroke("#c2185b");
                    series.labels().enabled(true);
                    series.labels().fontSize(10);
                    series.labels().fontColor("#212121");
                    series.labels().format("{%Value}");

                    series.tooltip()
                            .useHtml(true)
                            .format("function() {\n" +
                                    "            return '<span style=\"font-size: 13px\">' + this.value + ' scams reported</span>';\n" +
                                    "          }");


                    anyChartView.addScript("file:///android_asset/ireland.js");
                    anyChartView.addScript("file:///android_asset/proj4.js");
                    anyChartView.setChart(map);


                }
            }
        });





    }


    private List<DataEntry> getData() {
        List<DataEntry> data = new ArrayList<>();

        data.add(new mapstats_activity.CustomDataEntry("IE.491", "Cork", CorkCounter));
        data.add(new mapstats_activity.CustomDataEntry("IE.WD", "Waterford", WaterfordCounter));
        data.add(new mapstats_activity.CustomDataEntry("IE.KY", "Kerry", KerryCounter));
        data.add(new mapstats_activity.CustomDataEntry("IE.1533", "Limerick", LimerickCounter));
        data.add(new mapstats_activity.CustomDataEntry("IE.CW", "Carlow", CarlowCounter));
        data.add(new mapstats_activity.CustomDataEntry("IE.CN", "Cavan", CavanCounter));
        data.add(new mapstats_activity.CustomDataEntry("IE.CE", "Clare", ClareCounter));
        data.add(new mapstats_activity.CustomDataEntry("IE.DL", "Donegal", DonegalCounter));
        data.add(new mapstats_activity.CustomDataEntry("IE.7035", "Dublin", DublinCounter));
        data.add(new mapstats_activity.CustomDataEntry("IE.7034", "Dublin", DublinCounter));
        data.add(new mapstats_activity.CustomDataEntry("IE.7036", "Dublin", DublinCounter));
        data.add(new mapstats_activity.CustomDataEntry("IE.DN", "Dublin", DublinCounter));
        data.add(new mapstats_activity.CustomDataEntry("IE.1510", "Galway", GalwayCounter));
        data.add(new mapstats_activity.CustomDataEntry("IE.KE", "Kildare", KildareCounter));
        data.add(new mapstats_activity.CustomDataEntry("IE.KK", "Kilkenny", KilkennyCounter));
        data.add(new mapstats_activity.CustomDataEntry("IE.LS", "Laois", LaoisCounter));
        data.add(new mapstats_activity.CustomDataEntry("IE.LM", "Leitrim", LeitrimCounter));
        data.add(new mapstats_activity.CustomDataEntry("IE.LD", "Longford", LongfordCounter));
        data.add(new mapstats_activity.CustomDataEntry("IE.LH", "Louth", LouthCounter));
        data.add(new mapstats_activity.CustomDataEntry("IE.MO", "Mayo", MayoCounter));
        data.add(new mapstats_activity.CustomDataEntry("IE.MH", "Meath", MeathCounter));
        data.add(new mapstats_activity.CustomDataEntry("IE.3566", "Monaghan", MonaghanCounter));
        data.add(new mapstats_activity.CustomDataEntry("IE.OY", "Offaly", OffalyCounter));
        data.add(new mapstats_activity.CustomDataEntry("IE.RN", "Roscommon", RoscommonCounter));
        data.add(new mapstats_activity.CustomDataEntry("IE.SO", "Sligo", SligoCounter));
        data.add(new mapstats_activity.CustomDataEntry("IE.TY", "Tipperary", TipperaryCounter));
        data.add(new mapstats_activity.CustomDataEntry("IE.1532", "Tipperary", TipperaryCounter));
        data.add(new mapstats_activity.CustomDataEntry("IE.WH", "Westmeath", WestMeathCounter));
        data.add(new mapstats_activity.CustomDataEntry("IE.WX", "Wexford", WexfordCounter));
        data.add(new mapstats_activity.CustomDataEntry("IE.WW", "Wicklow", WicklowCounter));


        return data;
    }

    class CustomDataEntry extends DataEntry {
        public CustomDataEntry(String id, String name, Number value) {
            setValue("id", id);
            setValue("name", name);
            setValue("value", value);
        }
        public CustomDataEntry(String id, String name, Number value, mapstats_activity.LabelDataEntry label) {
            setValue("id", id);
            setValue("name", name);
            setValue("value", value);
            setValue("label", label);
        }
    }

    class LabelDataEntry extends DataEntry {
        LabelDataEntry(Boolean enabled) {
            setValue("enabled", enabled);
        }
    }

}