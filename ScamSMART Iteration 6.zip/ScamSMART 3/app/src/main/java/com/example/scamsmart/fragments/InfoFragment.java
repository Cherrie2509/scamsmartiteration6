package com.example.scamsmart.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.scamsmart.R;
import com.example.scamsmart.ui.callinfo_activity;
import com.example.scamsmart.ui.numberinfo_activity;
import com.example.scamsmart.ui.reportinfo_activity;
import com.example.scamsmart.ui.textinfo_activity;

public class InfoFragment extends Fragment implements View.OnClickListener {

    View view;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.info_fragment, container, false);
        Button btnPhoneInfo = view.findViewById(R.id.btnPhoneInfo);
        Button btnTextInfo = view.findViewById(R.id.btnTextinfo);
        Button btnNumberInfo = view.findViewById(R.id.btnNumberinfo);
        Button btnReportInfo = view.findViewById(R.id.btnReportinfo);
        getActivity().setTitle("Info Menu");
        btnPhoneInfo.setOnClickListener(this);
        btnTextInfo.setOnClickListener(this);
        btnNumberInfo.setOnClickListener(this);
        btnReportInfo.setOnClickListener(this);

        return view;
    }

    @Override
    public void onClick(View v) {
        switch(v.getId()) {
            case R.id.btnPhoneInfo:
                Intent intent  = new Intent(getActivity(), callinfo_activity.class);
                startActivity(intent);
                break;
            case R.id.btnTextinfo:
                Intent intent2  = new Intent(getActivity(), textinfo_activity.class);
                startActivity(intent2);
                break;
            case R.id.btnNumberinfo:
                Intent intent3  = new Intent(getActivity(), numberinfo_activity.class);
                startActivity(intent3);
                break;
            case R.id.btnReportinfo:
                Intent intent4  = new Intent(getActivity(), reportinfo_activity.class);
                startActivity(intent4);
                break;
        }

    }
}
