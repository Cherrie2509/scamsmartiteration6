package com.example.scamsmart.ui;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.Toast;

import com.example.scamsmart.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import org.jetbrains.annotations.NotNull;

public class editcontent_activity extends AppCompatActivity {

    //Activity that allows admin to edit the content of the information activities

    FirebaseFirestore fStore;
    String article;
    Button btnEdit, btnBack, btnPhoneInfo, btnTextInfo, btnHowInfo, btnReportInfo;
    EditText etContent;
    String newarticle;
    String type;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editcontent);

        setTitle("Edit Content");
        ActionBar actionBar;
        actionBar = getSupportActionBar();
        ColorDrawable colorDrawable
                = new ColorDrawable(Color.parseColor("#f64c73"));
        // Set BackgroundDrawable
        actionBar.setBackgroundDrawable(colorDrawable);
        actionBar.setDisplayOptions(actionBar.getDisplayOptions()
                | ActionBar.DISPLAY_SHOW_CUSTOM);
        ImageView imageView = new ImageView(actionBar.getThemedContext());
        imageView.setScaleType(ImageView.ScaleType.CENTER);
        imageView.setImageResource(R.drawable.scamsmartactiontiny);
        ActionBar.LayoutParams layoutParams = new ActionBar.LayoutParams(
                ActionBar.LayoutParams.WRAP_CONTENT,
                ActionBar.LayoutParams.WRAP_CONTENT, Gravity.RIGHT
                | Gravity.CENTER_VERTICAL);
        //layoutParams.leftMargin = 40;
        imageView.setLayoutParams(layoutParams);
        actionBar.setCustomView(imageView);

        btnEdit = findViewById(R.id.btnUpdateContent);
        btnBack = findViewById(R.id.btnBacktoAdminMenu);
        etContent = findViewById(R.id.etEditContent);
        btnPhoneInfo = findViewById(R.id.btnEditCall);
        btnTextInfo = findViewById(R.id.btnEditText);
        btnHowInfo = findViewById(R.id.btnEditHow);
        btnReportInfo = findViewById(R.id.btnEditReport);
        fStore = FirebaseFirestore.getInstance();
        //Declaring a document reference for each of the possible articles
        DocumentReference documentReference  = fStore.collection("InfoContent").document("PhoneScam");
        DocumentReference documentReference2  = fStore.collection("InfoContent").document("TextScam");
        DocumentReference documentReference3  = fStore.collection("InfoContent").document("ProtectNumber");
        DocumentReference documentReference4  = fStore.collection("InfoContent").document("ReportInfo");



        btnPhoneInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Displaying current content
                type = "PhoneScam";
                documentReference.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull @NotNull Task<DocumentSnapshot> task) {
                        if (task.isSuccessful()) {
                            DocumentSnapshot document = task.getResult();
                            Log.d("DB*****",document.getData().get("Article") + "");
                            article = String.valueOf(document.getData().get("Article"));
                            Log.d("CHECKARRAY",article);
                            addtoArticle(article);
                        }
                        else {
                            Toast.makeText(editcontent_activity.this, "Nothing retrieved" + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                        }

                    }
                });
            }
        });

        btnTextInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Displaying current content
                type = "TextScam";
                documentReference2.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull @NotNull Task<DocumentSnapshot> task) {
                        if (task.isSuccessful()) {
                            DocumentSnapshot document = task.getResult();
                            Log.d("DB*****",document.getData().get("Article") + "");
                            article = String.valueOf(document.getData().get("Article"));
                            Log.d("CHECKARRAY",article);
                            addtoArticle(article);
                        }
                        else {
                            Toast.makeText(editcontent_activity.this, "Nothing retrieved" + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                        }

                    }
                });
            }
        });


        btnHowInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Displaying current content
                type = "ProtectNumber";
                documentReference3.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull @NotNull Task<DocumentSnapshot> task) {
                        if (task.isSuccessful()) {
                            DocumentSnapshot document = task.getResult();
                            Log.d("DB*****",document.getData().get("Article") + "");
                            article = String.valueOf(document.getData().get("Article"));
                            Log.d("CHECKARRAY",article);
                            addtoArticle(article);
                        }
                        else {
                            Toast.makeText(editcontent_activity.this, "Nothing retrieved" + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                        }

                    }
                });
            }
        });


        btnReportInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Displaying current content
                type = "ReportInfo";
                documentReference4.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull @NotNull Task<DocumentSnapshot> task) {
                        if (task.isSuccessful()) {
                            DocumentSnapshot document = task.getResult();
                            Log.d("DB*****",document.getData().get("Article") + "");
                            article = String.valueOf(document.getData().get("Article"));
                            Log.d("CHECKARRAY",article);
                            addtoArticle(article);
                        }
                        else {
                            Toast.makeText(editcontent_activity.this, "Nothing retrieved" + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                        }

                    }
                });
            }
        });



        //Method to set whats in the edittext to overwrite the content
        //checks the type variable to determine which document reference to use
        btnEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            newarticle = etContent.getText().toString();

            switch (type) {
                case ("PhoneScam"):
                    updateArticle(documentReference);
                    break;
                case ("TextScam"):
                    updateArticle(documentReference2);
                    break;
                case ("ReportInfo"):
                    updateArticle(documentReference4);
                    break;
                case ("ProtectNumber"):
                    updateArticle(documentReference3);
                    break;

            }



            }
        });

        //This button brings the admin back to their menu
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent startIntent = new Intent(getApplicationContext(), adminmenu_activity.class);
                startActivity(startIntent);
            }
        });

    }

    private void addtoArticle(String article) {
        etContent.setText(article);
    }

    //https://firebase.google.com/docs/firestore/manage-data/add-data
    private void updateArticle(DocumentReference documentreference) {
        documentreference.update("Article",newarticle);
        Toast.makeText(editcontent_activity.this, "Article Updated", Toast.LENGTH_SHORT).show();
    }


}