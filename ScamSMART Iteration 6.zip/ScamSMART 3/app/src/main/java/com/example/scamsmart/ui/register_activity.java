package com.example.scamsmart.ui;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.scamsmart.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import org.jetbrains.annotations.NotNull;

import java.util.HashMap;
import java.util.Map;

public class register_activity extends AppCompatActivity {

    //This activity allows a user to register
    //Based on https://github.com/bikashthapa01/firebase-authentication-android/blob/master/app/src/main/java/net/smallacademy/authenticatorapp/Register.java

    Button btnRegister;
    EditText etEmail, etName, etPassword;
    ProgressBar pbRegister;
    FirebaseAuth auth;
    FirebaseFirestore fStore;
    String userID;
    Spinner spCounty;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        auth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();
        btnRegister = findViewById(R.id.btnRegisterNew);
        etEmail = findViewById(R.id.etsigninemail);
        etName = findViewById(R.id.etName);
        etPassword = findViewById(R.id.etsigninpassword);
        pbRegister = findViewById(R.id.pbRegister);
        spCounty = findViewById(R.id.spCounty);

        setTitle("Register");
        ActionBar actionBar;
        actionBar = getSupportActionBar();
        ColorDrawable colorDrawable
                = new ColorDrawable(Color.parseColor("#f64c73"));
        // Set BackgroundDrawable
        actionBar.setBackgroundDrawable(colorDrawable);
        actionBar.setDisplayOptions(actionBar.getDisplayOptions()
                | ActionBar.DISPLAY_SHOW_CUSTOM);
        ImageView imageView = new ImageView(actionBar.getThemedContext());
        imageView.setScaleType(ImageView.ScaleType.CENTER);
        imageView.setImageResource(R.drawable.scamsmartactiontiny);
        ActionBar.LayoutParams layoutParams = new ActionBar.LayoutParams(
                ActionBar.LayoutParams.WRAP_CONTENT,
                ActionBar.LayoutParams.WRAP_CONTENT, Gravity.RIGHT
                | Gravity.CENTER_VERTICAL);
        //layoutParams.leftMargin = 40;
        imageView.setLayoutParams(layoutParams);
        actionBar.setCustomView(imageView);

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String email = etEmail.getText().toString().trim();
                String password = etPassword.getText().toString().trim();
                final String fullName = etName.getText().toString();

                //Validation
                if(TextUtils.isEmpty(email)){
                    etEmail.setError("Email is Required.");
                    return;
                }

                if(TextUtils.isEmpty(password)){
                    etPassword.setError("Password is Required.");
                    return;
                }

                if(TextUtils.isEmpty(fullName)){
                    etName.setError("Name is Required.");
                    return;
                }

                if(password.length() < 6){
                    etPassword.setError("Password Must be >= 6 Characters");
                    return;
                }
                if(spCounty.getSelectedItemPosition() == 0) {
                    Toast.makeText(register_activity.this, "Please Select A Province", Toast.LENGTH_SHORT).show();
                    return;
                }

                pbRegister.setVisibility(View.VISIBLE);

                //Creating a user with firebase auth, I also create a user object in the Cloud Firestore so I have a corresponding table there
                auth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull @NotNull Task<AuthResult> task) {
                        if(task.isSuccessful()) {
                            Toast.makeText(register_activity.this, "User Created", Toast.LENGTH_SHORT).show();

                            userID = auth.getCurrentUser().getUid();

                            DocumentReference documentReference = fStore.collection("Users").document(userID);
                            Map<String,Object> user = new HashMap<>();
                            user.put("Name",fullName);
                            user.put("email",email);
                            user.put("type","regular");
                            user.put("id",userID);
                            user.put("County",spCounty.getSelectedItem());
                            //Insert new user
                            documentReference.set(user).addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void aVoid) {
                                    Log.d("SuccessStore", "onSuccess: user Profile is created for "+ userID);
                                }
                            }).addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Log.d("FailStore", "onFailure: " + e.toString());
                                }
                            });

                            Intent intent = new Intent(register_activity.this,signin_activity.class);
                            startActivity(intent);
                        }
                        else {
                            Toast.makeText(register_activity.this, "Error", Toast.LENGTH_SHORT).show();
                        }


                    }
                });
            }
        });

    }
}